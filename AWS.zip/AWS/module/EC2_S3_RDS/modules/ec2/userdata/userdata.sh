#!/bin/bash
sudo apt update -y
sudo apt install apache2 -y
sudo systemctl start apache2
sudo bash -c 'echo Your very first Web Apache Server > /var/www/html/index.html'
tags = {
    Name = "web-server"
  }
}
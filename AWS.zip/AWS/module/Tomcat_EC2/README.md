``` 
module "ec2" {
   source = "./modules/ec2"

    instance_name = "Tomcat"
    ami = "ami-0149b2da6ceec4bb0"
    instance_type = "t3.medium"
    subnet_id = "subnet-8f23b081"
    vpc_security_group_ids = ["${module.security_groups.security_group_id}"]
    key_name = "secret key"
    user_data = filebase64("./ec2_init.sh")    

    root_block = {
        size = "40"
        type = "gp2"
        encrypt = false
    }

    depends_on = [
      module.security_groups
    ]
 }

 module "security_groups" {
   source = "./modules/security_groups"

    ec2_sg_name = "security_group_name"
    vpc_id = "VPC_ID here"

    #write security group to open 80 and 443
    ingress= [
      {
        description = "HTTP"
        from_port = 8080
        to_port = 8080
        protocol = "tcp"
        cidr_blocks = ["0.0.0.0/0"]
      },
      {
        description = "HTTPS"
        from_port = 443
        to_port = 443
        protocol = "tcp"
        cidr_blocks = ["0.0.0.0/0"]
      },
      {
        description = "SSH"
        from_port = 22
        to_port = 22
        protocol = "tcp"
        cidr_blocks = ["0.0.0.0/0"]
      }
    ]

    egress = [ {
        description = "All traffic"
        from_port = 0
        to_port = 0
        protocol = "-1"
        cidr_blocks = ["0.0.0.0/0"]
    }]
 }
```

## NOTICE
- Please only use the ubuntu 20.0 or upper version. Tested on ubuntu 22.04. Fill the corresponding AMI ID that is available on the region you are choosing. 
- This installs the TomCat9. 
- You can change the region on the providers.tf file. 
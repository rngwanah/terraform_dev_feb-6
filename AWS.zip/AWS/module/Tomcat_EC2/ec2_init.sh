#! /bin/bash
#install tomcat server on ubuntu

sudo apt-get update 
sudo apt install openjdk-11-jdk -y
sudo apt-get install -y tomcat9 tomcat9-docs tomcat9-admin tomcat9-examples
sudo apt-get install -y git

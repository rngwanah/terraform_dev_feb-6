### Run the pre-init module to set up remote state using S3 and DynamoDB
Set the bucket and table variables before running
cd to pre-init folder and run terraform commands

## EC2 Resource template
run terraform commands from the root folder
Modules and Resources included
1. Backup  - AWS Backup resource and Policies
2. EC2 - Windows EC2 instance with EBS, IAM profile and policies, SSM agent install Powershell Script and System Manager Activation
3. File-System -create and enable AWS File System storage
4. LoadBalancer attached to EC2 with Route53 private DNS and record
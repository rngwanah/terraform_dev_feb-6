### Terraform Template with RDS Postgres Database and Secret Manager, KMS key encryption and S3 Glacier Storage

Add your credentials and remote state storage bucket and set the region and variables to the desired configuration.

Included AWS resources are RDS, Secret Manager and its IAM Policy, Database Security Groups, KMS Key and S3 Glacier Storage with its IAM policy.
The module provisions the following resources:

EKS cluster of master nodes that can be used together with the  eks_managed_node_groups one  and eks_managed_node_groups two modules to create a full-blown cluster

IAM Role to allow the cluster to access other AWS services

Min eks cluster version is cluster_version 1.27.

Adjust the AMi-type as per cluster workload.
ALL the node group in private subnets ,
Security group with each node group can modify the rules.
cluster_encryption_config_enabled and set deletion window at 7 days.

Use tls data source to get information, such as SHA1 fingerprint or serial number, about the TLS certificates that protects a URL.

Variables.tf is where we pass all the variables
terraform.tfvars file have the values of all the variables
main.tf store the value which will be use in the eks modules in the modules folder
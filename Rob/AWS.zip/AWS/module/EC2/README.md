## Use this module to create an AWS ec2 instance with below parameters.

- `ec2_name`
- `ami`
- `instance_type`
- `vpc_security_group_ids`
- `subnet_id`



## Example use case:
> Declare your backend configuration in the provider.tf file
```
terraform {
  backend "s3" {
     bucket       = ""
     key          = ""
     region       = ""
  }
}
```

> Declare the AWS provider in provider.tf file
```
provider "aws" {
  region = ""
}
```

> Call the ec2 module from top level main.tf file
```
module "ec2" {
  # Specify the source directory of the module, relative to the current working directory
  source = "./module/EC2/"
   ec2_name = ""
  ami = ""
  instance_type = ""
  vpc_security_group_ids = [""]
  subnet_id = ""
}

```

> The kms resource and variables are in the modules folder
```
./module/EC2/
```
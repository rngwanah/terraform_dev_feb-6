## Use this module to create an AWS lambda instance with below parameters.

- `kms_key_description`
- `kms_key_deletion_window_in_days`
- `my_kms_key_alias`




## Example use case:
> Declare your backend configuration in the provider.tf file
```
terraform {
  backend "s3" {
     bucket       = ""
     key          = ""
     region       = ""
  }
}
```

> Declare the AWS provider in provider.tf file
```
provider "aws" {
  region = ""
}
```

> Call the kms module from top level main.tf file
```
module "kms" {
  source = "./module/kms/"
  kms_key_description = ""
  my_kms_key_alias = ""
  kms_key_deletion_window_in_days = 
}
```

> The kms resource and variables are in the modules folder
```
./module/kms/
```
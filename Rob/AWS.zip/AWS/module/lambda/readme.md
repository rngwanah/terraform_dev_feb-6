## Use this module to create an AWS lambda instance with below parameters.

- `lambda_iam_role_name`
- `lambda_zip_path`
- `lambda_function_name`
- `lambda_handler`
- `lambda_runtime`
- `lambda_timeout`
- `lambda_memory_size`
- `iam_role_name`



## Example use case:
> Declare your backend configuration in the provider.tf file
```
terraform {
  backend "s3" {
     bucket       = ""
     key          = ""
     region       = ""
  }
}
```

> Declare the AWS provider in provider.tf file
```
provider "aws" {
  region = ""
}
```

> Call the lambda module from top level main.tf file
```
module "lambda" {
  source   = "./module/lambda/"
  lambda_iam_role_name    = ""
  lambda_zip_path         = ""
  lambda_function_name    = ""
  lambda_handler          = ""
  lambda_runtime          = ""
  lambda_timeout          =
  lambda_memory_size      = 
}
```

> The lambda resource and variables are in the modules folder
```
./module/lambda/

The lambda_function file is provided as an example
Need to create the lambda_function as a zip file and place in the correct path as defined by the lambda_zip_path parameter
```

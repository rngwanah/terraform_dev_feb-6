## Use this module to create a security group with below parameters.

- `vpc_name`
- `sg_name`
- `sg_description`




## Example use case:
> Declare your backend configuration in the provider.tf file
```
terraform {
  backend "s3" {
     bucket       = ""
     key          = ""
     region       = ""
  }
}
```

> Declare the AWS provider in provider.tf file
```
provider "aws" {
  region = ""
}
```

> Call the sg module from top level main.tf file
```
module "sg" {
  source = "./module/sg/"
  vpc_name = ""
  sg_name = ""
  sg_description = ""
}
```

> The sg resource and variables are in the modules folder
```
./module/sg/
```
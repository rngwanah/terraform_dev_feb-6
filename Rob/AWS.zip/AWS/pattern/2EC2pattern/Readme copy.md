Terraform Infrastructure as Code
This Terraform configuration deploys into a Virtual Private Cloud (VPC) and EC2 instances in AWS. The infrastructure is designed to support one or more EC2 instances within a specified VPC.

Prerequisites
Before you begin, ensure you have the following prerequisites:

Terraform installed on your local machine.
AWS credentials configured.
Configuration
The main.tf file defines the main infrastructure components and utilizes modules for better organization and reusability.

VPC Configuration
The VPC is created using the vpc module, and its parameters are configured in the locals block:

hcl
```
locals {
  vpc_name = "${var.project_name}-${var.env_name}-vpc"

  ec2_data = merge(
    { for idx, instance in var.ec2_instances : idx => {
      name          = instance.name
      instance_type = instance.instance_type
      ami           = instance.ami
      ports         = instance.ports
      subnet_id     = module.vpc.private_subnets[idx]
      key_name      = instance.key_name
    }}
  )
}

module "vpc" {
  source = "./modules/networking/vpc"
  vpc_name = local.vpc_name
  vpc_cidr = var.vpc_cidr  
  availability_zones             = var.availability_zones
  private_cidr_blocks = var.private_cidr_blocks
  public_cidr_blocks  = var.public_cidr_blocks
  common_tags = var.common_tags
  env_name = var.env_name
}
EC2 Instances Configuration
The EC2 instances are created using the ec2 module, and their parameters are configured in the locals block:

hcl
```
```
# create 1 or more instance.
module "ec2" {
  source = "./modules/ec2"
  ec2_instances = local.ec2_data
  env_name = var.env_name
  vpc_id = module.vpc.vpc_id
}
```
Usage
Clone this repository to your local machine.
bash
```
git clone <repository_url>
cd <repository_directory>
```
Update the variables.tf file with your desired values.

Initialize the Terraform configuration.
```
bash
terraform init
Apply the configuration to create the infrastructure.
```
```
bash

terraform apply
Confirm the changes and type "yes" when prompted.
```
Cleanup
To destroy the created infrastructure, run:
```
bash

terraform destroy
Type "yes" when prompted.
```

Notes
Ensure that you have the necessary AWS credentials and permissions configured.
Review the variables in the variables.tf file and adjust them according to your requirements.
